﻿using System.Windows.Forms;

namespace DemoApp
{
    public partial class Demo : Form
    {
        public Demo() => InitializeComponent();
    }
}
