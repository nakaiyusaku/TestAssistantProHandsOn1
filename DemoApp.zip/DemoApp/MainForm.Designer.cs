﻿namespace DemoApp
{
    partial class Demo
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this._tab = new System.Windows.Forms.TabControl();
            this._tabPageReserve = new System.Windows.Forms.TabPage();
            this._reservePage = new DemoApp.ReserveControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.originalControl1 = new DemoApp.OriginalControl();
            this._tab.SuspendLayout();
            this._tabPageReserve.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // _tab
            // 
            this._tab.Controls.Add(this._tabPageReserve);
            this._tab.Controls.Add(this.tabPage4);
            this._tab.Dock = System.Windows.Forms.DockStyle.Fill;
            this._tab.Location = new System.Drawing.Point(0, 0);
            this._tab.Name = "_tab";
            this._tab.SelectedIndex = 0;
            this._tab.Size = new System.Drawing.Size(573, 517);
            this._tab.TabIndex = 1;
            // 
            // _tabPageReserve
            // 
            this._tabPageReserve.Controls.Add(this._reservePage);
            this._tabPageReserve.Location = new System.Drawing.Point(4, 22);
            this._tabPageReserve.Name = "_tabPageReserve";
            this._tabPageReserve.Padding = new System.Windows.Forms.Padding(3);
            this._tabPageReserve.Size = new System.Drawing.Size(565, 491);
            this._tabPageReserve.TabIndex = 0;
            this._tabPageReserve.Text = "予約";
            this._tabPageReserve.UseVisualStyleBackColor = true;
            // 
            // _reservePage
            // 
            this._reservePage.Dock = System.Windows.Forms.DockStyle.Fill;
            this._reservePage.Location = new System.Drawing.Point(3, 3);
            this._reservePage.Name = "_reservePage";
            this._reservePage.Size = new System.Drawing.Size(559, 485);
            this._reservePage.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.originalControl1);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1024, 491);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Original Control";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // originalControl1
            // 
            this.originalControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.originalControl1.Location = new System.Drawing.Point(0, 0);
            this.originalControl1.Name = "originalControl1";
            this.originalControl1.Size = new System.Drawing.Size(1024, 491);
            this.originalControl1.TabIndex = 0;
            // 
            // Demo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(573, 517);
            this.Controls.Add(this._tab);
            this.Name = "Demo";
            this.Text = "Main";
            this._tab.ResumeLayout(false);
            this._tabPageReserve.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl _tab;
        private System.Windows.Forms.TabPage _tabPageReserve;
        private ReserveControl _reservePage;
        private System.Windows.Forms.TabPage tabPage4;
        private OriginalControl originalControl1;
    }
}

