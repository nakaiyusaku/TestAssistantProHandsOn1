﻿using System.Windows.Forms;

namespace DemoApp
{
    public partial class ReserveControl : UserControl
    {
        public ReserveControl() => InitializeComponent();

        void ButtonAddClick(object sender, System.EventArgs e)
        {
            using (var form = new ReserveForm())
            {
                if (form.ShowDialog(this) != DialogResult.OK) return;
                var row = _grid.Rows.Add();
                _grid.Rows[row].Cells[0].Value = form.GuestName;
                _grid.Rows[row].Cells[1].Value = form.Count;
                _grid.Rows[row].Cells[2].Value = form.ReserveDateTime;
                _grid.Rows[row].Cells[3].Value = form.IsNonSmorking;
            }
        }
    }
}
