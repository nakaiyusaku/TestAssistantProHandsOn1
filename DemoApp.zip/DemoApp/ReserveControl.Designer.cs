﻿namespace DemoApp
{
    partial class ReserveControl
    {
        /// <summary> 
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region コンポーネント デザイナーで生成されたコード

        /// <summary> 
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を 
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this._grid = new System.Windows.Forms.DataGridView();
            this._buttonAdd = new System.Windows.Forms.Button();
            this._colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._colCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._colDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._colNonSmorking = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this._grid)).BeginInit();
            this.SuspendLayout();
            // 
            // _grid
            // 
            this._grid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this._grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this._grid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this._colName,
            this._colCount,
            this._colDateTime,
            this._colNonSmorking});
            this._grid.Location = new System.Drawing.Point(0, 37);
            this._grid.Name = "_grid";
            this._grid.RowTemplate.Height = 21;
            this._grid.Size = new System.Drawing.Size(571, 367);
            this._grid.TabIndex = 0;
            // 
            // _buttonAdd
            // 
            this._buttonAdd.Location = new System.Drawing.Point(3, 8);
            this._buttonAdd.Name = "_buttonAdd";
            this._buttonAdd.Size = new System.Drawing.Size(75, 23);
            this._buttonAdd.TabIndex = 1;
            this._buttonAdd.Text = "追加";
            this._buttonAdd.UseVisualStyleBackColor = true;
            this._buttonAdd.Click += new System.EventHandler(this.ButtonAddClick);
            // 
            // _colName
            // 
            this._colName.HeaderText = "名前";
            this._colName.Name = "_colName";
            // 
            // _colCount
            // 
            this._colCount.HeaderText = "人数";
            this._colCount.Name = "_colCount";
            // 
            // _colDateTime
            // 
            this._colDateTime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this._colDateTime.HeaderText = "日時";
            this._colDateTime.Name = "_colDateTime";
            // 
            // _colNonSmorking
            // 
            this._colNonSmorking.HeaderText = "禁煙";
            this._colNonSmorking.Name = "_colNonSmorking";
            // 
            // ReserveControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this._buttonAdd);
            this.Controls.Add(this._grid);
            this.Name = "ReserveControl";
            this.Size = new System.Drawing.Size(571, 404);
            ((System.ComponentModel.ISupportInitialize)(this._grid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView _grid;
        private System.Windows.Forms.Button _buttonAdd;
        private System.Windows.Forms.DataGridViewTextBoxColumn _colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn _colCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn _colDateTime;
        private System.Windows.Forms.DataGridViewCheckBoxColumn _colNonSmorking;
    }
}
