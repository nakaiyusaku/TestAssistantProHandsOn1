﻿using System;
using System.Windows.Forms;

namespace DemoApp
{
    public partial class ReserveForm : Form
    {
        public ReserveForm()
            => InitializeComponent();

        public string GuestName => _textBoxName.Text;
        public string Count => _textBoxCount.Text;
        public string ReserveDateTime => _date.SelectionStart.ToString("yyyy/MM/dd " + _textBoxTime.Text);
        public bool IsNonSmorking => _checkBoxNonSmoke.Checked;

        void ButtonOKClick(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_textBoxName.Text) ||
                !int.TryParse(_textBoxCount.Text, out var val1) ||
                !DateTime.TryParse(_textBoxTime.Text, out var val2))
            {
                MessageBox.Show("入力が不正です", "予約");
                return;
            }
            DialogResult = DialogResult.OK;
        }
    }
}
